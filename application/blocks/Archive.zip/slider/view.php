<?php
	defined('C5_EXECUTE') or die("Access Denied.");
?>

<h1><?php echo $text; ?></h1>
<p><?php echo $content; ?><small><?php echo $subcontent; ?></small> </p>
