<?php
    defined('C5_EXECUTE') or die("Access Denied.");
?>

<h3>Template Form</h3>
<p>contains options for the template like checkboxes and selects.</p>
<p>For example colours can be a change in class, no need to a block template for this.</p>