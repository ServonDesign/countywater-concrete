<?php
	defined('C5_EXECUTE') or die("Access Denied.");
?>

<h4 class="alert__announcement--message"><?php echo $text; ?>: <span><?php echo $content; ?></span>
